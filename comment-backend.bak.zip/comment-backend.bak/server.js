const express = require('express');
const fs = require('fs');
const bcrypt = require('bcrypt');
const app = express();
const port = 3000;
const commentsFile = 'comments.json';
const usersFile = 'users.json';

app.use(express.json());

// Initialize files if they don't exist
if (!fs.existsSync(commentsFile)) {
    fs.writeFileSync(commentsFile, JSON.stringify([]));
}
if (!fs.existsSync(usersFile)) {
    fs.writeFileSync(usersFile, JSON.stringify([]));
}

// GET /api/comments - Fetch all comments
app.get('/api/comments', (req, res) => {
    try {
        const comments = JSON.parse(fs.readFileSync(commentsFile));
        res.status(200).json(comments);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch comments' });
    }
});

// POST /api/comments - Add a new comment
app.post('/api/comments', (req, res) => {
    const { username, comment } = req.body;
    if (!username || !comment) {
        return res.status(400).json({ error: 'Username and comment are required' });
    }
    try {
        const comments = JSON.parse(fs.readFileSync(commentsFile));
        comments.push({ username, comment });
        fs.writeFileSync(commentsFile, JSON.stringify(comments, null, 2));
        res.status(201).json({ message: 'Comment saved successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to save comment' });
    }
});

// POST /api/register - Register a new user
app.post('/api/register', async (req, res) => {
    const { username, password, email, fullName } = req.body;
    console.log('Received registration request:', { username, password, email, fullName });
    if (!username || !password || !email || !fullName) {
        console.log('Missing required fields');
        return res.status(400).json({ error: 'Username, password, email, and full name are required' });
    }
    try {
        const users = JSON.parse(fs.readFileSync(usersFile));
        console.log('Current users:', users);
        if (users.some(user => user.username === username)) {
            console.log('Username already exists:', username);
            return res.status(400).json({ error: 'Username already exists' });
        }
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        const newUser = {
            username,
            password: hashedPassword,
            email,
            fullName,
            middleName: '',
            birthday: '',
            age: '',
            location: '',
            phone: '',
            isStudent: false,
            profileImage: ''
        };
        users.push(newUser);
        console.log('New user to be saved:', newUser);
        fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
        console.log('Users after saving:', JSON.parse(fs.readFileSync(usersFile)));
        res.status(201).json({ message: 'User registered successfully', username });
    } catch (error) {
        console.error('Error in /api/register:', error);
        res.status(500).json({ error: 'Failed to register user' });
    }
});

// POST /api/login - Login an existing user
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }
    try {
        const users = JSON.parse(fs.readFileSync(usersFile));
        const user = users.find(user => user.username === username);
        if (!user) {
            return res.status(400).json({ error: 'Invalid username or password' });
        }
        // Verify password
        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(400).json({ error: 'Invalid username or password' });
        }
        // Return user data without password
        const { password: _, ...userData } = user;
        res.status(200).json({ message: 'Login successful', user: userData });
    } catch (error) {
        res.status(500).json({ error: 'Failed to login' });
    }
});

// GET /api/user - Get user data for the logged-in user
app.get('/api/user', (req, res) => {
    const username = req.query.username;
    if (!username) {
        return res.status(400).json({ error: 'Username is required' });
    }
    try {
        const users = JSON.parse(fs.readFileSync(usersFile));
        const user = users.find(user => user.username === username);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        const { password: _, ...userData } = user;
        res.status(200).json(userData);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch user data' });
    }
});

// POST /api/user/update - Update user profile
app.post('/api/user/update', (req, res) => {
    const { username, fullName, middleName, birthday, age, location, phone, isStudent, profileImage } = req.body;
    if (!username) {
        return res.status(400).json({ error: 'Username is required' });
    }
    try {
        const users = JSON.parse(fs.readFileSync(usersFile));
        const userIndex = users.findIndex(user => user.username === username);
        if (userIndex === -1) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Update user data (preserve password)
        users[userIndex] = {
            ...users[userIndex],
            fullName: fullName || users[userIndex].fullName,
            middleName: middleName || users[userIndex].middleName,
            birthday: birthday || users[userIndex].birthday,
            age: age || users[userIndex].age,
            location: location || users[userIndex].location,
            phone: phone || users[userIndex].phone,
            isStudent: isStudent !== undefined ? isStudent : users[userIndex].isStudent,
            profileImage: profileImage || users[userIndex].profileImage
        };
        fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
        res.status(200).json({ message: 'Profile updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update profile' });
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
